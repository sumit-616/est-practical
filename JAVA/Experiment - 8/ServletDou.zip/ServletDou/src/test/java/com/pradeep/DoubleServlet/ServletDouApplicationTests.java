package com.pradeep.DoubleServlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServletDouApplicationTests {

	@Test
	void contextLoads() {
	}

}
