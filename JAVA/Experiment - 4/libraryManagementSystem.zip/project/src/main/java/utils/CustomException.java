package utils;

public class CustomException extends Exception {
	
	
	



	public  CustomException() {
		super("Something went wrong");
	}
	
	
	public CustomException(String message) {
		super(message);
	}
	
	
	

	

}
