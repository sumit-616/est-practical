package com.BankSystem.Services;

public class CustomerService {
	
	
	
	
	public void deleteCustomer() {
		
		
	}

}
