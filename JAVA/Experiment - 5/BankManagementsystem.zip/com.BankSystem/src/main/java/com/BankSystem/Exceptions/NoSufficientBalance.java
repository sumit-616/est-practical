package com.BankSystem.Exceptions;


public class NoSufficientBalance extends Exception{
	


	NoSufficientBalance(String message){
		super(message);
	}
}