package com.BankSystem.Exceptions;

  public class NoAccountFound extends Exception{
	
	
	
	NoAccountFound(String message) {
		super(message);
	}
	

}

